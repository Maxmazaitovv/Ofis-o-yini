# Ofis Hayoti (pixel o'yin)
1. Bu papkadagi hamma narsani yangi GitHub repoga yuklang (push).
2. Repo > Actions > "Build APK" ishlaguncha kuting (~5 daqiqa).
3. Tugagach "Artifacts" bo'limidan `ofis-hayoti-apk` ni yuklab oling (ichida app-debug.apk).
Brauzerda sinash: www/index.html ni oching. Boshqaruv: strelka/WASD, bo'shliq yoki Enter = harakat.
